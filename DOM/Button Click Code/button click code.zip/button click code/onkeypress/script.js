const inputBox = document.getElementById('input-box') 
const display = document.getElementById('heading')


// // adding a keypress event listener to the inputbox
inputBox.addEventListener('keypress', function(e){
    display.innerText ="you have Pressed " + e.key
});