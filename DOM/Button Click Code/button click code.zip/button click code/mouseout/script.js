const mainpart = document.getElementById("main");

mainpart.addEventListener("mouseout", () => {
    alert("the alert occurs due to cursor left the pink box.");
});