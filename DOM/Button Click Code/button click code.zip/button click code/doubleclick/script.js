const doubleclickablebutton = document.getElementById("doubleclick");

doubleclickablebutton.addEventListener("dblclick", () => {
    alert("The double click button successfully working.");
});