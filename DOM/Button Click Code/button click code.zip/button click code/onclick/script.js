const clickableButton = document.getElementById("button1");

clickableButton.addEventListener("click", () => {
    document.body.style.backgroundColor = "aqua";
});