const mouseover1 = document.getElementById("button1");
const mouseover2 = document.getElementById("button2");
const mouseover3 = document.getElementById("button3");

mouseover1.addEventListener("mouseover", () => {
    message();
});
mouseover2.addEventListener("mouseover", () => {
    message();
});
mouseover3.addEventListener("mouseover", () => {
    message();
});

function message() {
    alert("This is the restricted area. Please don't enter");
};
