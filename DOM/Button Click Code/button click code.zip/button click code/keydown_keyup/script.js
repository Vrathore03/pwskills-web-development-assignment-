let container = document.getElementById("main");
let display = document.getElementById("heading");


document.addEventListener("keydown", function (e) {
  document.body.style.backgroundColor = "pink";
  display.innerText = e.key + " is keyDown";
});

document.addEventListener("keyup", function (e) {
  document.body.style.backgroundColor = "green";
  display.innerText = e.key + " is keyUp";
});
