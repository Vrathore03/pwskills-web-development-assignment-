// script.js
//Select the counter element and buttons

const counterElement = document.getElementById("counter");
const incrementButton = document.getElementById("increment-btn");
const decrementButton = document.getElementById("decrement-btn");
const resetButton = document.getElementById("reset-btn");

// Initialize counter value
let counter = 0;

// Function to update the counter display
function updateCounterDisplay() {
    counterElement.textContent = counter;
}

// Event listner for the increment button
incrementButton.addEventListener('click', () => {
    if(counter >= 10) {
        alert("10+ values not allowed");
    }
    else{
        counter+=1;
        updateCounterDisplay();
    }
});

// Event listner for the decrement button
decrementButton.addEventListener('click', () => {
    if(counter > 0) {
        counter-=1;
        updateCounterDisplay();
    }
    else{
        alert("Negative values not allowed");
    }
});

// Event listner for the reset button
resetButton.addEventListener('click', () => {
    counter = 0;
    updateCounterDisplay();
});

// Initialize counter display on page load
updateCounterDisplay();
